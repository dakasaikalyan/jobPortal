"use client"

import { useState } from "react"
import { BarChart3, Users, Briefcase, Calendar, FileText, Settings, Bell } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const dashboardStats = [
  { title: "Total Applications", value: "24", change: "+12%", icon: FileText, color: "text-blue-600" },
  { title: "Interview Scheduled", value: "8", change: "+25%", icon: Calendar, color: "text-green-600" },
  { title: "Profile Views", value: "156", change: "+8%", icon: Users, color: "text-purple-600" },
  { title: "Saved Jobs", value: "12", change: "+3%", icon: Briefcase, color: "text-orange-600" },
]

const recentApplications = [
  {
    id: 1,
    company: "Google",
    position: "Senior Frontend Developer",
    status: "Interview Scheduled",
    appliedDate: "2024-01-15",
    logo: "🔍",
  },
  {
    id: 2,
    company: "Microsoft",
    position: "Product Manager",
    status: "Under Review",
    appliedDate: "2024-01-12",
    logo: "🪟",
  },
  {
    id: 3,
    company: "Apple",
    position: "iOS Developer",
    status: "Application Sent",
    appliedDate: "2024-01-10",
    logo: "🍎",
  },
]

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Interview Scheduled":
        return "bg-green-100 text-green-800"
      case "Under Review":
        return "bg-yellow-100 text-yellow-800"
      case "Application Sent":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Welcome back, John! 👋</h1>
            <p className="text-gray-600">Here's what's happening with your job search today.</p>
          </div>
          <div className="flex gap-3 mt-4 md:mt-0">
            <Button variant="outline" size="icon">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {dashboardStats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title} className="hover:shadow-lg transition-shadow border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className="text-sm text-green-600 font-medium">{stat.change} from last month</p>
                    </div>
                    <div className={`p-3 rounded-full bg-gray-100 ${stat.color}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-fit">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="applications">Applications</TabsTrigger>
            <TabsTrigger value="interviews">Interviews</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Applications */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Recent Applications
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentApplications.map((app) => (
                    <div key={app.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">{app.logo}</div>
                        <div>
                          <h4 className="font-semibold text-gray-900">{app.position}</h4>
                          <p className="text-sm text-gray-600">{app.company}</p>
                          <p className="text-xs text-gray-500">Applied on {app.appliedDate}</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(app.status)}>{app.status}</Badge>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full bg-transparent">
                    View All Applications
                  </Button>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full justify-start gap-3 h-12 bg-gradient-to-r from-blue-600 to-purple-600">
                    <Briefcase className="w-5 h-5" />
                    Browse New Jobs
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-3 h-12 bg-transparent">
                    <FileText className="w-5 h-5" />
                    Update Resume
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-3 h-12 bg-transparent">
                    <Users className="w-5 h-5" />
                    Network Connections
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-3 h-12 bg-transparent">
                    <BarChart3 className="w-5 h-5" />
                    View Analytics
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="applications">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>All Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Your application history and status tracking will appear here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="interviews">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Upcoming Interviews</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Your scheduled interviews and preparation materials will appear here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Profile Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Manage your profile information, resume, and preferences here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
